package test;

public class mainTest {
	public static void main(String args[]){
		Double x=3.0;
		Double y=4.0;
		System.out.println(x);
		System.out.println(y);
		x=x*x;
		y=y*y;
		System.out.println(x);
		System.out.println(y);
		Double res=Math.sqrt(x+y);
		System.out.println(res);
		
	}
}
