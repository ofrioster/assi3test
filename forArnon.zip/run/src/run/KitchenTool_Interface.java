package run;

public interface KitchenTool_Interface {
	
	
	public String getKitchenToolName();
	public boolean getKitchenTool();
	public void returnKitchenTool();
	public int numberOfKitchenTools();
	public int getNumberOfKitchenTool();


}
