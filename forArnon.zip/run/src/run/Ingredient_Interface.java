package run;

public interface Ingredient_Interface {
	
	public String getIngredientName();
	public  boolean getIngredient();
	public void returnIngredient();
	public int getNumberOfIngredient();

}
