package run;

public class assi3 {
	
	public static void main(String args[]){
		System.out.print("good");
		System.out.print("now?");
		//ssss
	}


}
